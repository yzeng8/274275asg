import random # import the random module

def biased_rolls(prob_list, s, n):
    random.seed(s) # make seed of this random s
    result = [] # create an empty list for later appending
    for x in range(n): # A for loop for n times
        toss = random.random() # random float number from [0,1)
        for i in range(1,len(prob_list)+1): # index all the possibility in the pro_list
            totalpossibility = sum(prob_list[0:i]) # sum of all the possiblity in the prob_list have occured
            if i == len(prob_list): #when it's the last element of the list and when the random number is more than the sum above
                if totalpossibility <= toss:
                    a = len(prob_list)
                    result.append(a)
                    break
            if toss <= totalpossibility: # when the random number is less than the sum above, add it to the result list above
                a = i
                result.append(a)
                break
            
    return result
    pass

def draw_histogram(m, rolls, width):
    frequency = {} #create an empty dictionary..
    print('Frequency Histogram: ' + str(m) + '-sided Die') # Print the name of the histogram
  
    for item_value in range(1, m+1): # get the item and value into dictionary
        frequency[item_value] = rolls.count(item_value)
    
    max_frequency = max(frequency.values())

    for key_value in frequency: #  get the number of each count and print out proportionally with # and-
       frequency[key_value] = round(frequency[key_value] * width / max_frequency )
       print(str(key_value)+'.'+'#' * frequency[key_value]  + '-' * round(width - frequency[key_value]))
    pass

if __name__ == "__main__": # main function to run the above two function
    rolls = biased_rolls()
    print(rolls)
    draw_histogram()
    pass
