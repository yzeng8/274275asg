// Name: Steven Xu
// CCID: fx4
// CMPUT275 Wi,2022
// Assignment: Navigation System Part I
// Dijkstra's alg. implementaton goes here
#include "dijkstra.h"
#include "digraph.h"
#include <iostream>
#include <unordered_map>
#include <queue>
#include <utility>
#include "wdigraph.h"

using namespace std;

class ComparableGreater {
    //A compare class for priority queue, use replace max heap as min heap 
public:
    // Define the operator () for comparsion
    bool operator() (const PIPIL& lhs, const PIPIL& rhs) const {
        // parameters: lhs(the first edge and their time)
        //            rhs(the second edge and their time)
        // Return: the greater time(which is d in the later function)
        return (lhs.second.second > rhs.second.second); // min heap
    }
};


void dijkstra(const WDigraph& graph, int startVertex, 
    unordered_map<int, PIL>& searchTree) {
    // Parameter:
    // WDigraph& graph (A graph we created using WDigraph which contains all the vertices and edges for Edmonton Roads)
    // startVertex (The vertex we start at)
    // searchTree (A unordered map that stores reachable vertices and their cost between of the startVertex)
    // Return:
    // None(A void function)

    // each active fire is stored as (v, (u, d)) 
    // which implies that it is a fire started at u
    // currently burning the (u,v) edge 
    // and will reach v at time d
    
    // a min heap is implemented with priority queue of O(log)
    // finding and extracting the 'earliest' fire that reaches another vertex

    // Declare a priority queue
    priority_queue <PIPIL, vector<PIPIL>, ComparableGreater> fires;

    // at time 0, the startVertex burns, we set the predecesor of
    // startVertex to startVertex (as it is the first vertex)
    fires.push(PIPIL(startVertex, PIL(startVertex, 0)));

    // while there is an active fire
    while (!fires.empty()) {
        
        // finding the fire that reaches its endpoint earliest
        int v = fires.top().first; 
        int u = fires.top().second.first; 
        long long d = fires.top().second.second;
        
        // remove this fire
        fires.pop();

        // if v is already "burned", skip it
        if (searchTree.find(v) != searchTree.end()) {
            continue;
        }

        // record that 'v' is burned at time 'd' by a fire started from 'u'
        searchTree[v] = PIL(u, d);

        // now start fires from all edges exiting vertex 'v'
        for (auto iter = graph.neighbours(v); iter != graph.endIterator(v); iter++) {
            int nbr = *iter;

            // 'v' catches on fire at time 'd' and the fire will reach 'nbr'
            // at time d + (length of v->nbr edge)
            long long t_burn = d + graph.getCost(v, nbr);
            fires.push(PIPIL(nbr, PIL(v, t_burn)));
        }
    }
}
