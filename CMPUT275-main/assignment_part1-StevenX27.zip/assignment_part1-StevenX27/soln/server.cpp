// Name: Steven Xu
// CCID: fx4
// CMPUT275 Wi,2022
// Assignment: Navigation System Part I

// implementation of the server program
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <list>
#include "wdigraph.h"
#include "dijkstra.h"

using namespace std;


struct Point {
    // A sturcture to store the information of each vertex or other points 
    long long lat; // latitude of the point
    long long lon; // longitude of the point
};


long long manhattan(const Point& pt1, const Point& pt2) {
    //Parameters:
    //pt1: First point
    //pt2: Second point

    // Return the Manhattan distance between the two given points
    return abs(pt1.lat - pt2.lat) + abs(pt1.lon - pt2.lon);
}

/*
Read Edmonton map data from the provided file and
load it into the WDigraph object passed to this function.
Store vertex coordinates in Point struct and map each
vertex identifier to its corresponding Point struct variable.
PARAMETERS:
filename: the name of the file that describes a road network
graph: an instance of the weighted directed graph (WDigraph) class
points: a mapping between vertex identifiers and their coordinates

*/
void readGraph(string filename, WDigraph& graph, unordered_map<int, Point>& points) {
    //Parameters:
    // filename(The name of the file that contains the information of all the vertices and edges of edmonton roads)
    // graph(An empty graph that we declared in the main scope, it will contains all the vertices and edges of edmonton roads after this function)
    // points(An unoredered map that contains its identifier, longtitude and lattitude of each vertex)

    //Returns:
    // None(A void function)

    //Open the edmonton roads
    fstream fileStream(filename);

    // declare a string to represent each line of input
    string strSingleLine;
    
    //if file does not exist return 
    if(!fileStream.is_open() ){
        return;
    }   
    
    // While not EOF, input one line
    while(getline(fileStream, strSingleLine)){

        //To identify wheter it's a vertex or an edge
        string method = strSingleLine.substr(0, strSingleLine.find(","));

        //since we extracted the method above, we erase this part to extract further info
        strSingleLine.erase(0,strSingleLine.find(",")+1);
        
        //first vertex identifier
        int index;

        // second vertex identifier
        int index2;

        // lon of a vertex
        long long longtitude;

        // lat of a vertex
        long long lattitude;

        // cost of an edge
        long long cost;

        // if it's an Vertex, extract its identifier, its lattitude and its longtitude
        if (method =="V"){

            // extract its identifier
            index = stoi(strSingleLine.substr(0, strSingleLine.find(",")));
            strSingleLine.erase(0,strSingleLine.find(",")+1);

            // extract its lattitude
            lattitude = static_cast<long long>(stod(strSingleLine.substr(0, strSingleLine.find(",")))*100000);
            strSingleLine.erase(0,strSingleLine.find(",")+1);

            // extract its longtitude
            longtitude = static_cast<long long>(stod(strSingleLine.substr(0, strSingleLine.find(",")))*100000);

            // add a vertex to the graph and the points(unordered map)
            points[index] = {lattitude, longtitude};
            graph.addVertex(index);
        }

        //if it's an edge, extract the identifier of 2 vertices and the cost between them
        if (method =="E"){
            // the identifier of the start vertex of the edge
            index = stoi(strSingleLine.substr(0, strSingleLine.find(",")));
            strSingleLine.erase(0,strSingleLine.find(",")+1);

            // the indentifier of the end vertex of the edge
            index2 = stoi(strSingleLine.substr(0, strSingleLine.find(",")));
            strSingleLine.erase(0,strSingleLine.find(",")+1);

            // the manhattan distance between 2 edges            
            cost = manhattan(points[index], points[index2]);
            graph.addEdge(index,index2,cost);
        }

    }
    //close the stream
    fileStream.close();
    return;
}

int main(){
    // Parameters: None
    // Return: 0(Means the program runs successfully)

    // The name of the text file that contains all the info of edmonton roads
    string filename = "edmonton-roads-2.0.1.txt";

    // declare an empty graph
    WDigraph graph;

    // To store the info of each vertex
    unordered_map<int, Point> points;

    // To store the reachable paths of each startVertex
    unordered_map<int, PIL> searchTree;

    // Store vertices and edges in the graph
    readGraph(filename,graph,points);

    // The start word
    string start;

    // StartVertex and endVertex
    int startVertex;
    int endVertex;
    
    cin >> start;

    // When the first input word is "R"
    if (start =="R"){
        
        // Input the start point and the end point
        Point point_start;
        Point point_end;
        cin >> point_start.lat >> point_start.lon >> point_end.lat >> point_end.lon;

        long long distance = 0;
        
        //Find the closest vertex of the start point
        for (auto iter = points.begin(); iter!=points.end();iter++){
            long long new_distance= manhattan(point_start,iter->second);
            
            // Add the distance of the first vertex we compare for later comparison
            if(iter == points.begin()){
                distance = new_distance;
                startVertex = iter->first;
            }
            // Not the first Vertex we compare
            else{
                // If the new distance is less than the distance of previous vertex, replace the previous vertex
                if(new_distance < distance){
                    distance = new_distance;
                    startVertex = iter->first;
                }
            }
        }

        // Find the closest vertex of the end point
        for (auto iter = points.begin(); iter!=points.end();iter++){
            long long new_distance= manhattan(point_end,iter->second);

            // Add the distance of the first vertex we compare for later comparison
            if(iter==points.begin()){
                distance = new_distance;
                endVertex = iter->first;
            }
            // Not the first Vertex we compare
            else{
                // If the new distance is less than the distance of previous vertex, replace the previous vertex
                if(new_distance < distance){
                    distance = new_distance;
                    endVertex = iter->first;
                }
            }
        }
    }

    // find reachable vertices the their cost between of the startVertex
    dijkstra(graph, startVertex, searchTree);

    // declare a list to store the path between 2 point
    list<int> path;

    // For user input "A"
    string aha;

    // when there is not a path between 2 vertices
    if (searchTree.find(endVertex) == searchTree.end()) {
        //print "N 0"
        cout << "N "<< path.size()<<endl;

        //When user enter "A", print "E" which means no more path. if the input is not "A", it will keep asking until it's A
        cin >> aha;
        while(aha != ""){
            if(aha == "A"){
                cout << "E"<< endl;
                break;
            }
            else{
                cin >> aha;
            }
        }
    }
    //When there is a path
    else {

        // go through the search tree and find the path
        int stepping = endVertex;
        while (stepping != startVertex) {
        path.push_front(stepping);

        // crawl up the search tree one step
        stepping = searchTree[stepping].first;
        }

        // put the startVertex in the path
        path.push_front(startVertex);

        // Print "N" and the size of the path
        cout << "N " << path.size()<<endl;

        //Print the path between 2 points with order
        for (list<int>::iterator itr = path.begin(); itr != path.end(); ++itr){
            // Only print the path after client acknowledge "A"
            cin >> aha;
            while(aha != ""){
                if(aha == "A"){
                    cout << "W " <<points[*itr].lat << " " << points[*itr].lon << endl;
                    break;
                }
                else{
                    cin >> aha;
                }
            }
        }
        

        //When user enter "A", print "E" which means no more path. if the input is not "A", it will keep asking until it's A
        cin >> aha;
        while(aha != ""){
            if(aha == "A"){
                cout << "E"<< endl;
                break;
            }
            else{
                cin >> aha;
            }
        }
    }

    // end of program
    return 0;
}