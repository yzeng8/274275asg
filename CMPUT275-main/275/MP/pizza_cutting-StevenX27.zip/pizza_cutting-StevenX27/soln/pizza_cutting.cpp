#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	int number, slices, power;
	cin >> number >> slices;
	power = 0;
	
	if (number == 1 and slices != 1){
		cout << "BAD" << endl;
	}
	
	else{
		while (pow(number,power) < slices){
			power += 1;
		}
		
		if (pow(number,power) == slices){
			cout << "GOOD" << endl;
		}
		else{
			cout << "BAD" << endl;
		}
	}

	// declare your variables
	// read the input
	// solve, good luck!

	return 0;
}
