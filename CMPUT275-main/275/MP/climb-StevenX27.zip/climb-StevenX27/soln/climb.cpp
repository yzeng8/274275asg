#include <iostream>
using namespace std;

int main() {
  int n;
  cin >> n;
  
  int waypoint[n] ={};
  int output[n] ={};
  
  for(int i =0; i<n;i++){
    cin >> waypoint[i];
    }
  
  int count = 0;
  output[n-1] = 0;
  
  for(int i = n-1; i>0; i--){
    if (waypoint[i-1] < waypoint[i]){
      count +=1;
      output[i-1] = count;
      }
    else {
      output[i-1] = 0;
      count = 0;
      }
    }
  
  for(int i=0; i<n;i++){
    if (i==n-1){
      cout << output[i] << endl;
      }
    else{
      cout << output[i]  << " ";
      }
    
    }

  return 0;
}
