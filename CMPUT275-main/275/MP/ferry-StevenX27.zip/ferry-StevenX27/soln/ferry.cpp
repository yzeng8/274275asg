#include <iostream>
using namespace std;
int main() {
  int n,m;
  cin >> n >> m;

  if ()

  int west[n] ={10, 20};
  int east[m] = {50,30};
  
  for (int i = 0; i <n; i++) {
    cin >> west[i];
    }
    
  for (int i = 0; i<m; i++){
    cin >> east[i];
    }
  
  int wait_time = west[0];
  for (int i=0; i<n; i++){
    if (wait_time >= west[i]){
      wait_time += 100;
      }
    else{
      wait_time = west[i] +100;
      }
    if (i= n-1 && west[i+1]<east[i+1]){
      if (wait_time >= west[i+1] || wait_time >=east[i]){
        wait_time += 100;
        }
      else{
        wait_time = west[i+1] +100;
        }
      }
    else{
      
      }
    
    }

    cout << wait_time<<endl;

  return 0;
}
