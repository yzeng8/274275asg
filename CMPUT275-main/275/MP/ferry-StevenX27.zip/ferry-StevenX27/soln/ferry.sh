#!/bin/bash
g++ ferry.cpp -o ferry -Wall -std=c++11 && ./ferry
rm -f ./ferry