#!/bin/bash
g++ planning_practice.cpp -o planning_practice -Wall && ./planning_practice
rm -f ./planning_practice
