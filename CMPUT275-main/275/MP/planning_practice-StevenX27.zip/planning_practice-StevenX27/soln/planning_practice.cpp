#include <iostream>
using namespace std;

int main(){
    
    int n ;
    int t ;
    cin >> n >> t;

    int out[n];
    int home[n];
    
    
    for (int i = 0 ; i < n; i++) {
        cin >> out[i] >> home[i];
    }
    
    int max = out[0];
    for(int i = 0; i < n; i++){
        if(out[i] > max){
            max = out[i];
        }
    }
    
    int min = home[0];
    for (int i = 0; i<n; i++ ){
      if(home[i]< min){
        min = home[i];
      }  
    }
    
    if (min < max){
      cout << "IMPOSSIBLE"<< endl;
      }
    else{
      int hours = min - max;
      if ( t%hours != 0){
        int days = t/hours + 1;
        cout << days <<endl;
        }
      else{
        int days = t/hours;
        cout << days << endl;
        }
      

      }
    
    
    
    return 0;
}
    
    