#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int main() {
  int n ;
  string s;
  cin >> n >> s;
  int count =0;
  
  sort(s.begin(),s.end());
  
  for (int i = 0; i <=n-1;i++) {
  
    if (s[i] == s[i+1]){
      count += 2;
      i += 1;
      }
  
    else {
      continue;
      }
    }
  

  if (count == 0 ){
    cout << 1 << endl;
    }
  
  else if (n == count) {
    cout << count << endl;
    }
  
  else {
    cout << count + 1 << endl;
    }
  
  

  return 0;
}
