#!/bin/bash
g++ constructing_palindromes.cpp -o constructing_palindromes -Wall -std=c++11 -g && ./constructing_palindromes
rm -f ./constructing_palindromes
