#include <iostream>
using namespace std;


int main(){
    long long int n;
    long long int m;
    cin >> n >> m;

    long long int numbers[n]= {};
    
    long long int forward[n] = {};
    long long int backward[n] = {};

    long long int result[n] = {};

    for (int i = 0 ; i < n; i++) {
        cin >> numbers[i];
        if (i == 0){
          forward[i] = numbers[i];
          }
        else{
          forward[i] = forward[i-1]*numbers[i];
          }
    }
    
    for (int i = n-1; i>= 0; i--){
      if (i == n-1){
        backward[i] = numbers[i];
        }
      else{
        backward[i] = backward[i+1]*numbers[i];
        }
      }
    
    for (int i= 0; i < n; i++){
      long long int sum_before=1;
      long long int sum_after= 1;
      if (i-m <=0 && i+m >= n-1){
        result[i] = 0;
        }
      else{
        if(i - m <=0){
          sum_before = 1;
          }
        else{
          sum_before = forward[i-m-1];
          }
        if(i + m >= n-1){
          sum_after = 1;
          }
        else{
          sum_after = backward[i+m+1];
          }
        result[i] = sum_before*sum_after;
        }
        
      }
      

    for (int i =0; i < n; i++){
      if (i == n-1){
          cout << result[i] << endl;
      }
      else{
          cout << result[i]<< " ";
      }
     }
    
    
    
    return 0;
}