#!/bin/bash
g++ missing_multipliers.cpp -o missing_multipliers -Wall && ./missing_multipliers
rm -f ./missing_multipliers
