#include <iostream>

using namespace std;

int main() {
  int n;
  cin >> n;

  int floor[n] = {};

  for(int i =0; i<n; i++){
    cin >> floor[i];
  }

  int total = 0;
  for (int i = 1; i<n; i++){
    if(floor[i] > floor[i-1]){
      total += floor[i]-floor[i-1];
    }
  }

  cout << total << endl;
  return 0;
}
