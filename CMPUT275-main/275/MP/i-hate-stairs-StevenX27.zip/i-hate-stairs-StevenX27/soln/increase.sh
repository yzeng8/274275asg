#!/bin/bash
g++ increase.cpp -o output -Wall && ./output
rm -f ./output
