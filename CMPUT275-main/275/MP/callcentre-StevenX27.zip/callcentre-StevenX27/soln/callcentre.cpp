#include <iostream>
#include <numeric>
using namespace std;

int main() {
  int n, q;
  cin >> n >> q;
  int calls[n] = {};
  int sum[n] = {};
  
  for (int i = 0; i < n; i++) {
    cin >> calls[i];
    if (i==0){
        sum[0] = calls[0];
    }
    else{
        sum[i] = sum[i-1] + calls[i];
    }
  }
 
  int a, b;
  
  
 
  for (int i = 0; i < q; i++){
    cin >> a >> b;
    if (a == b){
      cout << calls[a-1] << endl;
      }
    else{
        if (a == 1){
            cout << sum[b-1] << endl;
        }
        else{
            cout << sum[b-1] - sum[a-2] << endl;
        }
      
      
      }
    } 

  return 0;
}