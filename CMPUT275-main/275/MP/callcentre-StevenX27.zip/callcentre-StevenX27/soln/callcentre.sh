#!/bin/bash
g++ callcentre.cpp -o callcentre -Wall && ./callcentre
rm -f ./callcentre
