#include "ref_manager.h"
#include <iostream>
#include <unordered_map>
#include <cassert>
using namespace std;

ReferenceManager::ReferenceManager() {
  // constructor, it will create two array pointers and garbage and set all the elements to NULL initially;
  // It will also set the inital value of numToDelete to 0;

  numToDelete = 0;
  for (int i = 0; i < MAX_PTRS; i++) {
    pointers[i] = NULL;
  }
  for (int i = 0; i < MAX_PTRS; i++) {
    garbage[i] = NULL;
  }
}

ReferenceManager::~ReferenceManager() {
  // destructor, it will reassign all the elements in the pointers array to NULL and then collect all the words and print them out

  for (int i = 0; i < MAX_PTRS; i++){
    //reassign the element to Null
    reassignPointer(i, NULL);

  }

  garbageCollect();


  // CODE HERE
}

void ReferenceManager::garbageCollect() {
  //Collect the words that are resigned backed to 0 then print them; and delete the dynamic array from the heap;
  // Arguments: None
  // Return : None

  for (int i = 0; i < numToDelete; i++){
    
    // print the collected garbage element
    cout << garbage[i] << endl;
    
    // deallocate the memory
    delete garbage[i];
  }
  // reset numToDelete back to zero because there may be further actions
  numToDelete = 0;


}

void ReferenceManager::reassignPointer (unsigned int ptrIndex, const char* newAddr){ 
  // Arguments: ptrIndex(the location of in the pointers), newAddr(the string of chars)
  // Return: none
  // Reassign the corresponding element in the pointers array to newAddr and record its occurences
  // Collect the garbage if it no longer occurs in the array(has to occur at least once before)

  if (pointers[ptrIndex] == NULL && newAddr == NULL){
    // when both the element in pointers and newAddr are NULL, do nothing

  }

  // when both the element in the poiners and newAddr are the same character string, do nothing
  else if (pointers[ptrIndex] == newAddr && newAddr != NULL){
    
  }

  // Main case 1, when newAddr is not Null
  else if (newAddr != NULL) {

  // when newAddr is replacing the previous character string
    if (newAddr != pointers[ptrIndex] && pointers[ptrIndex] != NULL) {
      
      // the previous word count will decrement by 1
      refCount[pointers[ptrIndex]] --;

      // after subtituting, if now there is no previous word left in the array, it becomes a garbage
      if(refCount[pointers[ptrIndex]] == 0){
        
        // one more garbage
        numToDelete ++;

        //assign it to the garbage array
        garbage[numToDelete-1] = pointers[ptrIndex];
      }
      // actual subtitution
      pointers[ptrIndex] = newAddr;
      
      //one more newAddr element in the array
      refCount[pointers[ptrIndex]] ++;
     
    }

    // else if the element never occured in the array; then initialize it in the unordered_map to be 1; then the corresponding element to be newAddr;
    else if (refCount[newAddr] == 0) {
      pointers[ptrIndex] = newAddr;
      refCount[newAddr] = 1;
    }

    // if it ouccurs before, just assign the corresponding element to be newAddr, then count one more occurences 
    else {
      pointers[ptrIndex] = newAddr;
      refCount[pointers[ptrIndex]] ++;
     
    }
  }

  // main case 2, if newAddr is NULL; this means reassign the corresponding element back to NULL;
  else if (newAddr == NULL){

  //if the elements occcured in the pointer, we decrement its count by 1

    if (refCount[pointers[ptrIndex]] != 0 ){

      refCount[pointers[ptrIndex]] --;

      // if after reassignment, this word no longer occurs in the pointers, it becomes a garbage to collect,
      if (refCount[pointers[ptrIndex]] == 0){
        
        //one more garbage to collect
        numToDelete ++;

        //collect the garbage
        garbage[numToDelete-1] = pointers[ptrIndex];;

      }
      // reassign it to NULL
      pointers[ptrIndex] = newAddr;
    }
  
  }
  else {

  }
}
  

void ReferenceManager::readString (unsigned int ptrIndex, unsigned int length) {
  // read the input string for later usage
  // Arguments: ptrIndex(the location of in the pointers), length(the length of the input word)

  // allocate memory from the heap to create a character array to store the actual words;
  char *strings = new char[length+1];

  cin >> strings;

  
  // use reassignPointer to reassign the readed string to the pointer array
  reassignPointer(ptrIndex, strings);

}

const char* ReferenceManager::getPtr (unsigned int ptrIndex) {
  assert(ptrIndex < MAX_PTRS);
  return pointers[ptrIndex];
}


