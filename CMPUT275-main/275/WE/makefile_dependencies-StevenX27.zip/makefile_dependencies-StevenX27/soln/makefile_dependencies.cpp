// Name: Steven Xu
// CCID: fx4
// CMPUT275 Wi,2022
// WE7: makefile_denpendencies

#include <iostream>
#include <unordered_map>
#include <vector>
#include <unordered_set>
#include <string>
#include <stack>
#include <list>
using namespace std;


void recursive_dfs(unordered_map<string,vector<string>>& graph, string make_target, unordered_set<string> & reached) {
	// a recursive dfs algorithm is used to print all the target file's parameter files
	// Parameters:
	// graph: an unordered map that stores the name of the target files and its parameters
	// make_target: the target file we are making now

	// if the file has been created before, no need to create again
	if (reached.find(make_target) != reached.end())
		return; // it was visited before

	// if never reached before, now it's created
	reached.insert(make_target);

	// Iterate over all elements of the vector, print all the elements, and go through them to check if the target file's parameter files need to be created and its parameter files
	for (auto &i : graph[make_target]){
		if (graph.find(i)!= graph.end() && reached.find(i) == reached.end()){
			recursive_dfs(graph,i,reached);
			cout << i<< " ";
		};
	}

}

int main(){
	// The main function of this program
	// Parameters: None
	// Returns: 0(Means th program runs successfully)

	// number of make commands
	int n;
	// number of actual requests
	int m;
	cin >> n >> m;

	// an unordered map to store the name of the target files and its parameters
	unordered_map <string, vector<string>> parameters;

	// an unordered set to store all the target files that has been made
	unordered_set <string> visited;

	// number of parameters of each make command
	int x;
	for (int i = 0; i < n; i++){

		// input the number of parameters
		cin >> x;

		// create a string to hold the name of the target file
		string targetname;
		cin >> targetname;

		// since ":" is in the string, need to pop it
		targetname = targetname.substr(0, targetname.find(":"));

		// a string to temporarily hold the name of each parameter
		string paras;
		for (int j = 0; j < x ;j++){
			// input the the name of each parameters and store them in a vector in orders
			cin >> paras;
			parameters[targetname].push_back(paras);
		}
	}

	// since the make command consist of: "make" "target file"
	// to store "make" itself
	string make;
	// to store the name of the target file
	string make_target;

	// loop through the number of requests
	for(int i = 0; i < m; i++){
		cin >> make;
		// if the command is actually "make" then continue
		if (make == "make"){
			// input the target file
			cin >> make_target;

			// if the target file has been created before, then no need to create again
			if(visited.find(make_target) != visited.end()){
				cout << "make: `" << make_target << "' is up to date."<< endl;
			}
			// if the target file was never created before
			else{
				// using dfs algo, create its parameter files
				recursive_dfs(parameters, make_target, visited);
				// create the file itself
				cout << make_target <<endl ;
			}
		}
		// if the command is not make, break
		else {
			return 0;
		}
	}
	// if the program runs successfully
	return 0;

}
