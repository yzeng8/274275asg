#!/bin/bash
g++ rivers.cpp -o rivers -Wall -std=c++11 -g && ./rivers
rm -f ./rivers
