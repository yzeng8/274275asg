// Remember style matters!
#include <iostream>
#include <unordered_map>
using namespace std;

int query(int* a, int n, int u, int v){
	// Parameters:
	// *a: the pointer to the start of array where the first river meet the larger rivers
	// n: number of rivers, an integer
	// u: where this river first meets larger river, an integer
	// v: where this river first meets larger river, an integer
	// Return: When these river first meet each other


// an unorder_map to store the path of the shorter river
  unordered_map<int, int> first_river;
 // initialize k, an index for later usage 
  int k;
  
  // when the first river starts at ocean, 2 rivers can only meets at the ocean
  if (u == 0){
  	return *a;
  }

  // when the second river starts at ocean, 2 rivers can only meets at the ocean
  else if(v ==0 ){
  	return *a;
  }

  // when 2 rivers starts at the same location, they already meets
  else if (u == v){
  	return u;
  }

  // find the shorter path of river between u or v

  if (v > u) {

  	// store the start of the river into the map
  	first_river[u] = u;

  	//store all the paths river u goes through
  	while (*(a+u-1) > 0) {
  		first_river[*(a+u-1)] = *(a+u-1);
  		u = *(a+u-1);

  	}

  	// the last location will be at the ocean
  	first_river[0] = 0;

  	// initilize the value of k, v is the longer river
  	k = v;

  }
  // when v is a shorter river
  else {
  	// store the start of the river into the map
  	first_river[v] = v;

  	//store all the paths river v goes through
  	while (*(a+v-1) > 0) {
  	
  	first_river[*(a+v-1)] = *(a+v-1);
  	v = *(a+v-1);

  }

  // the last location will be at the ocean
  first_river[0] = 0;

  // initilize the value of k, u is the longer river
  k = u;
  }

  // while the second river's path doesn't meet the path the first river, try the next path
  while (first_river.find(*(a+k-1)) == first_river.end()){
  	k = *(a+k-1);

  	// if the second river is already at the ocean and we still haven't met, they meet at the ocean
  	if (k == 1){
  		return 0;
  	}
  }

  // otherwise, meet will be the location they meet and return it.

  int meet = first_river[*(a+k-1)];



  return meet;
}


int main() {
// n is the number of rivers, q is the queries that are asked	
  int n; 
  int q;
  cin >> n >> q;
  
 // initlize an array to save the river's path
  int a[n];
  for (int i= 0; i < n; i++){
    cin >> a[i];
    }
  
  // initialize the the start of 2 rivers(the query)
  int u, v;
  
  //based on the number of queries, print out the location
  for (int i = 0; i < q; i++){

  	//input the start of 2 rivers
    cin >> u >> v;

    // find where they first meet
    int k = query (a ,n ,u ,v);
    
    // print where they meet
    cout << k << endl;
    
    }
  
  return 0;
}