//---------------------------------------------------
// Name : Steven Xu
// ID: 1663052
// CMPUT 275 , Winter 2022
//
// Exercise 1: Twin primes
// ---------------------------------------------------
// Remember, style matters!
// While you may rely upon additional functions 
// ensure isPrime and twinPrime follow the specifications.
// -----------------------
#include <iostream>
using namespace std; 


bool isPrime(int n) {
  // isPrime() check whether a number is a prime number
  // Arguments: n (number)
  // Return: true or false(whether it's a prime number)
  if (n == 0 || n == 1) {
    // 0 and 1 are not prime number
    return false;
  }
  int i = 2;

  while (i<n) {
  // when i < n, once if the remainder of n/i is 0, it's not a prime number
    if (n%i == 0) {
      return false;
    }
    else {
      // check if n is divisible by i+1 
      i += 1;
    }
  }
  // if it passes all the test, it's a prime number
  return true;
}

void twinPrimes(int k) {
  // twinPrimes() prints k pairs of twin prime
  // Argument: k (number of pairs wanted)
  // Return: None

  // First twin prime starts at 3
  int i = 3;
  // Number of pairs printed
  int n = 0;

  while (n < k) {
    // when i and i+2 are both prime, print their values
    if (isPrime(i) && isPrime(i+2)) {
      cout << i << " " << i+2 << endl; 
      // Test later number
      i += 1;
      // one more printed pair of values
      n += 1;
    }
    else {
    // Test later number 
      i += 1;
    }
  }
}
 

int main() {
  // Main function
  // num represents an integer, mode is char
  int num;
  char mode;
  
  //input both values
  cin >> mode >> num;
  
  // when mode is p, run isPrime() checks if a number is a prime number, if it is, print 'prime', else print 'not prime'
  if (mode == 'p'){
    if (isPrime(num)){
      cout << "prime" << endl;
    }
    else {
      cout << "not prime" << endl;
    }
  }
  // when mode is t, print k pairs of twin primes 
  else if (mode == 't'){
    twinPrimes(num);
  }

  return 0;
}