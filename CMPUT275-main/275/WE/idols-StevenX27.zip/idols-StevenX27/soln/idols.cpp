//---------------------------------------------------
// Name : Steven Xu
// ID: 1663052
// CMPUT 275 , Winter 2022
//
// Exercise 2: idols
// ---------------------------------------------------
// Remember, style matters!
// While you may rely upon additional functions 
// ensure reverse is declared and functions as described
#include <iostream> // this is the only header you may use (for cin, cout, and endl)
using namespace std;

void reverse(int* begin, int* end){
	// reverse from the begin to end - 1

  int j = 0;

  while (begin + j < end-j){
  	// while the first pointer's memory location is less than the memory location of the second pointer(approach to the middle), swap values
    
    int temp = *(begin + j);
    *(begin + j) = *(end - j -1);
    *(end - j -1) = temp;
    j ++ ;

  }
}




int main() {
	// input the number of values
	int n;
	cin >> n;
	
	// input the actual n values
	int array[n];

	for (int i = 0 ; i < n; i++) {
		cin >> array[i];
	}

	// initialize a dynamic array in the heap to store idol values
	int* idols = new int[n];

	// the last element of the array has to be an idol
	idols[n-1] = array[n-1];


	for (int i = 0; i < n-1  ; i++){
		//looking for idols element by element and put them in the corresponding location in the array idols, 
		//we will put an 0 at the corresponding location, if the location in thn array is not an idol,
		
		for (int j = i+1; j <= n-1; j++) {
			if (array[i] <= array[j]){
				idols[i] = -1000000;
				break;
			}
			else if(j == n-1){
				idols[i] = array[i];
			}
			else {
				idols[i] = -1000000;

			}
		}
	}


	// initialize another dynamic array to store the location of an idol values
	// eg. if the first value in the array is an idol value, we will store 0 in this num[]
	int* num = new int[n];

	// initialize a k to keep track of how many location values we stored in the num[], k is the actual value minus 1
  int k =0;
  
  for (int i = 0; i <= n-1; i++) {
  	// print all the idol values
  	
  	if (idols[i] == -1000000 ) {

  	}

  	else if( i == n-1 ) {
  		cout << idols[i]<< endl;
  		// the last value in the array will always be an idol value, we store the location of it
  		num[k] = i;
  	}
  	else {
  		cout << idols[i] << " ";
  		// store the location of an idol value
  		num[k] = i;
  		k++;
  	}
  }

  if (k==0){
  	// when there is only one idol values, reverse the entire array except for the last one
  	reverse(array, array+num[k]);
  }
  else if (num[0] == 0){
  	// when the first value of an array is an idol value
  	
  	for (int i = 0; i < k+1; i++){
  		// have reverse one more time compared to else
  		if (i == 0){
  			reverse(array, array+num[i]);
  		}
  		else{
  			reverse(array+num[i-1]+1, array+num[i] );
  		}
  	}
  }
  else{
  	// when it's other cases, just reverse as instructions
  	for (int i = 0; i < k; i++){
  		// reverse one less time than the else if above
  		if (i == 0){
  			reverse(array, array+num[i]);
  		}
  		else{
  			reverse(array+num[i-1]+1, array+num[i] );
  		}
  	}
  }

  // delete the dynamic array
  delete num;
  delete idols;
  
  // print the reverse the array  
  for (int i = 0; i < n; i++){
  	if (i == n-1){
  		cout << array[i]<< endl;
  	}
  	else{
  		cout << array[i]<< " ";
  	}
  }

	return 0;

}