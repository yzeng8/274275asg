#!/bin/bash
make -s && ./we7_solution
