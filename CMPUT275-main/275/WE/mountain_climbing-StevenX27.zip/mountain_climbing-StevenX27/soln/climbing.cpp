// Name: Steven Xu
// CCID: fx4
// CMPUT275 Wi,2022
// WE7: mountain_climbing
typedef unsigned int uint;
#include <iostream>
#include <cmath>
using namespace std;


uint climbing(const uint *heights, uint length, uint rest, uint limit){
  // A function to find the min burst time of climbing
  // Parameters: 
  // heights: An array that has the position of all the ledges
  // length: the number of ledges we have in the array
  // rest: the lenght of each rest
  // limit: the limit time of mountian climbing
  // Returns:
  // The burst time

  // No rest in this case, any rest will cause it to exceed the limit
  if(heights[length-1] == limit){
    return limit;
    }
  // we can rest
  else{
    // The max number of times that we can rest
    uint rest_times = (limit - heights[length-1])/rest;

    // low and high are implementations of binary search
    uint low =0;
    uint high = limit;
    
    // binary search for the min burst time
    while(low < high){
      // the guess for burst is in the middle
      uint mid = (high+low)/2;

      // to count the times that we rest for the current burst time(A sign to show whether we need to guess higher or lower)
      uint times  = 0;

      // to test if this burst can reach the next ledge or not, to hold the value of each run

      uint per_run = 0;

      // go through each position
      for (uint i = 0; i < length; i++){
        // when just started heading for the first ledge
        if (i == 0){
          // if we can reach the first ledge
          if (mid >= heights[i]){
            per_run = heights[i];
          }
          // if we can't reach the first ledge, our guess needs to be higher
          else{
            times = rest_times+1;
            break;
          }
        }
        // When we already pass the first ledge
        else{
          // if the current burst can reach the next ledge, no need to rest
          if (mid >= per_run + (heights[i]-heights[i-1])){
            // count the distance we already ran for
            per_run += heights[i] - heights[i-1];
          }
          // if we can't reach the next ledge, need to rest
          else{
            // count the number of rest
            times += 1;

            // if the current burst can never reach the next ledge, our guess needs to be higher
            if (mid < heights[i]-heights[i-1]){
              times = rest_times +1;
              break;
            }
            // if the current burst can reach the next ledge, our new run starts from the previoud ledge
            else{
              per_run = heights[i]-heights[i-1];
            }
            
          }
        }
      }

      // if we rest less than max rest_times, which means we can burst less, we need to guess lower
      if(rest_times > times){
       high = mid;
      }
      // if we rest the same times as the max rest_time, we need to check
      else if (rest_times == times){
        // if this run is more than burst, we can try to burst less, thus guess lower
        if(per_run < mid){
          high = mid;
        }
        // if this run is indential to the run, no need to guess anymore, it is the min burst time
        else if(per_run == mid){
          //return the min burst time
          return mid;
        }
        // if this run is less than the burst time, we need to guess higher
        else{
          low = mid+1;
        }
      }
      // if we rest more than max rest_time, which means we need to burst more, we need to guess higher
      else{
        low = mid+1;
      }
    }

    // return the min_burst time
    return low;
  }
}

int main() {
  //The main function of this program
  //Parameters: None
  //Returns: 0(Which means the programs runs successfully)

  // number of ledges
  int n;

  // The time for each rest
  uint rest;

  // The time limit for the mountain climbing
  uint limit;

  // read in the above values
  cin >> n >> rest >> limit;

  // position of each ledge

  // read in the position of each ledge
  uint heights[n] = {};
  for (int i = 0; i < n; i++){
    cin >> heights[i];
  }

  // The function we defined to find the min burst time
  uint burst = climbing(heights, n, rest, limit);

  // print the min burst time
  cout << burst<<endl;
  
  return 0;
}
