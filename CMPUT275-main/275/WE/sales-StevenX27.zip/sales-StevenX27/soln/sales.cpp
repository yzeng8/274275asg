#include <iostream>
#include <unordered_map>
using namespace std;


int main() {
  int n;
  int T;
  cin >> n >> T;
  unordered_map <int,int> haha;
  int array[n];

  for (int i = 0; i < n; i++)
  {
    cin >> array[i];
    haha[array[i]] = array[i];
    }
  
  for (int i = 0; i < n; i++)
  {
    int k = T - array[i];
    if (i == n-1 && haha.find(k) == haha.end()){
      cout << "NO"<< endl;
      break;
      }
    else if (haha.find(k) == haha.end() || k == array[i]){
    
      }
    else if (haha.find(k) != haha.end()){
      cout << "YES" << endl;
      break;
      }
    else{

    }

    }

  return 0;
}
  
  