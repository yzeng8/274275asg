#!/bin/bash
g++ sales.cpp -o sales -Wall -std=c++11 -g && ./sales
rm -f ./sales
