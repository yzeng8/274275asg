﻿#ifndef MATRIX_H
#define MATRIX_H

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;

class Matrix {
public:
    //constructor to initialize a matrix rows x columns with number init
    Matrix(size_t num_rows, size_t num_columns, float init);

    //construcor to create a matrix rows x colums with custom values
    Matrix(size_t num_rows, size_t num_columns, float *arr_ptr);

    //A copy constructor to copy an current instance
    Matrix(const Matrix& matrixLocal);

    //destructor of the class, it will deallocate the memory we used from the heap
    ~Matrix();


    // Addition of 2 different matrix with compatible size
    Matrix operator+(const Matrix& other);

    // Subtraction of 2 different matrix with compatible size
    Matrix operator-(const Matrix& other);

    // negation of 2 different matrix with compatible size
    Matrix operator-();

    // multiplication 2 different matrix with compatible size
    Matrix operator*(const Matrix& other);


    float* operator[]( size_t rowIndex){ 
        return _pFloatArray[rowIndex]; 
    }
    const float* operator[]( size_t rowIndex) const{ 
        return _pFloatArray[rowIndex]; 
    }
    Matrix transpose();

    friend ostream& operator<<(ostream& os,const Matrix& matrixLocal);
    friend istream& operator>>(istream& is,const Matrix& matrixLocal);

    float getElement(size_t rowIndex, size_t columnIndex) const;
    size_t Rows() const {
        return _num_rows;
    }
    size_t Columns() const {
        return _num_columns;
    }

    void destroy();


private:
    float** _pFloatArray = nullptr;
    size_t _num_rows = 0;
    size_t _num_columns = 0;
};


#endif

