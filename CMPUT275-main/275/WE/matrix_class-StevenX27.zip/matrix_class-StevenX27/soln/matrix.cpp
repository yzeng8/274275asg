﻿#include "matrix.h"
using namespace std;

Matrix::Matrix(size_t num_rows, size_t num_columns, float init){
    if( num_rows == 0 || num_columns == 0 ){
        return;
    }

    _num_rows = num_rows;
    _num_columns = num_columns;

    _pFloatArray = new float* [_num_rows];

    for(size_t rowIndex = 0; rowIndex < _num_rows; rowIndex++){
        _pFloatArray[rowIndex] = new float[_num_columns];
    }

    for(size_t rowIndex = 0; rowIndex< _num_rows; rowIndex++){
        for(size_t columnIndex = 0; columnIndex< _num_columns; columnIndex++){
            _pFloatArray[rowIndex][columnIndex] = init;
        }
    }
}

Matrix::Matrix(size_t num_rows, size_t num_columns, float *arr_ptr){
    if( num_rows == 0 || num_columns == 0 ){
        return;
    }
    _num_rows = num_rows;
    _num_columns = num_columns;

    _pFloatArray = new float* [_num_rows];

    for(size_t rowIndex = 0; rowIndex < _num_rows; rowIndex++){
        _pFloatArray[rowIndex] = new float[_num_columns];
    }

    for(size_t rowIndex = 0; rowIndex< _num_rows; rowIndex++){
        for(size_t columnIndex = 0; columnIndex< _num_columns; columnIndex++){
            _pFloatArray[rowIndex][columnIndex] = arr_ptr[rowIndex*num_columns + columnIndex];
        }
    }
}


Matrix::Matrix(const Matrix& matrixLocal){

    _num_rows = matrixLocal.Rows();
    _num_columns = matrixLocal.Columns();

    _pFloatArray = new float*[_num_rows];

    for(size_t rowIndex = 0; rowIndex < _num_rows; rowIndex++){
        _pFloatArray[rowIndex] = new float[_num_columns];
    }

    for(size_t rowIndex = 0; rowIndex< _num_rows; rowIndex++){
        for(size_t columnIndex = 0; columnIndex< _num_columns; columnIndex++){
            _pFloatArray[rowIndex][columnIndex] = matrixLocal._pFloatArray[rowIndex][columnIndex];
        }
    }
}




Matrix::~Matrix(){
    for(size_t i = 0; i < _num_rows; i++){
        delete[] _pFloatArray[i];
    }
    delete[] _pFloatArray;
}


float Matrix::getElement(size_t rowIndex, size_t columnIndex) const {
    if(rowIndex < _num_rows && columnIndex < _num_columns ){
        return _pFloatArray[rowIndex][columnIndex];
    }
    //return NaN;
    return 0;
}



Matrix Matrix::operator-(const Matrix& other){
    Matrix matrixLocal(_num_rows,_num_columns,0.0);

    for(size_t rowIndex = 0; rowIndex< _num_rows; rowIndex++){
        for(size_t columnIndex = 0; columnIndex< _num_columns; columnIndex++){
            matrixLocal._pFloatArray[rowIndex][columnIndex] = _pFloatArray[rowIndex][columnIndex]- other._pFloatArray[rowIndex][columnIndex];
        }
    }
    return matrixLocal;
}



Matrix Matrix::operator-(){
    Matrix matrixLocal(_num_rows,_num_columns,0.0);

    for(size_t rowIndex = 0; rowIndex< _num_rows; rowIndex++){
        for(size_t columnIndex = 0; columnIndex< _num_columns; columnIndex++){
            matrixLocal._pFloatArray[rowIndex][columnIndex] = -_pFloatArray[rowIndex][columnIndex];
        }
    }
    return matrixLocal;
}


Matrix Matrix::operator+(const Matrix& other){
    Matrix matrixLocal(_num_rows,_num_columns,0.0);

    for(size_t rowIndex = 0; rowIndex< _num_rows; rowIndex++){
        for(size_t columnIndex = 0; columnIndex< _num_columns; columnIndex++){
            matrixLocal._pFloatArray[rowIndex][columnIndex] = _pFloatArray[rowIndex][columnIndex]+ other._pFloatArray[rowIndex][columnIndex];
        }
    }
    return matrixLocal;
}


Matrix Matrix::operator*(const Matrix& other){
    Matrix matrixLocal(_num_rows,other._num_columns,0.0);


    for(size_t rowIndex = 0; rowIndex < _num_rows; rowIndex++){
        for(size_t columnIndex = 0; columnIndex < other._num_columns; columnIndex++){
            for(size_t rowIndex2 = 0; rowIndex2 < other._num_rows; rowIndex2++){
                matrixLocal._pFloatArray[rowIndex][columnIndex] += _pFloatArray[rowIndex][rowIndex2] * other._pFloatArray[rowIndex2][columnIndex];
            }

        }
    }
    return matrixLocal;
}



ostream& operator<<(ostream& os,const Matrix& matrixLocal){
    for(size_t i32RowsIndex = 0; i32RowsIndex < matrixLocal.Rows(); i32RowsIndex++){
        for(size_t i32ColumIndex = 0; i32ColumIndex < matrixLocal.Columns(); i32ColumIndex++ ){
            os <<matrixLocal.getElement(i32RowsIndex, i32ColumIndex);
            
            if( i32ColumIndex + 1 != matrixLocal.Columns()){
                os <<" ";
            }
        }
        if( i32RowsIndex + 1 < matrixLocal.Rows()){
            os <<endl;
        }
    }
    return os;
}



istream& operator>>(istream& is, const Matrix& matrixLocal){

    for(size_t i32RowsIndex = 0; i32RowsIndex < matrixLocal.Rows(); i32RowsIndex++){
        for(size_t i32ColumIndex = 0; i32ColumIndex < matrixLocal.Columns(); i32ColumIndex++ ){
            is >> matrixLocal._pFloatArray[i32RowsIndex][i32ColumIndex];
        }
    }

    return is;
}


Matrix Matrix::transpose(){
    Matrix matrixLocal(_num_columns,_num_rows,0.0);

    for(size_t rowIndex = 0; rowIndex< _num_rows; rowIndex++){
        for(size_t columnIndex = 0; columnIndex< _num_columns; columnIndex++){
            matrixLocal._pFloatArray[columnIndex][rowIndex] = _pFloatArray[rowIndex][columnIndex];
        }
    }

    return matrixLocal;
};


void Matrix::destroy(){
    if( _pFloatArray != nullptr ){
        for(size_t rowIndex = 0; rowIndex < _num_rows; rowIndex++){
            if( _pFloatArray[rowIndex] != nullptr ){
                delete _pFloatArray[rowIndex];
            }
        }
        delete _pFloatArray;
    }
}
