#!/bin/bash
NAME=we5_solution
if ! [ -f $NAME ]
then
    make -s $NAME
    rm -f *.o
fi
chmod +x $NAME
./$NAME
rm -f $NAME
