// Name: Steven Xu
// CCID: fx4
// CMPUT275 Wi,2022
// Assignment: Navigation System Part II
// implementation of the server program
#include <iostream>
#include <cassert>
#include <fstream>
#include <string>
#include <list>
#include <cstring>
#include <cmath>

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "wdigraph.h"
#include "dijkstra.h"
using namespace std;

struct Point {
    long long lat, lon;
};

// returns the manhattan distance between two points
long long manhattan(const Point& pt1, const Point& pt2) {
  long long dLat = pt1.lat - pt2.lat, dLon = pt1.lon - pt2.lon;
  return abs(dLat) + abs(dLon);
}

// finds the id of the point that is closest to the given point "pt"
int findClosest(const Point& pt, const unordered_map<int, Point>& points) {
  pair<int, Point> best = *points.begin();

  for (const auto& check : points) {
    if (manhattan(pt, check.second) < manhattan(pt, best.second)) {
      best = check;
    }
  }
  return best.first;
}

// read the graph from the file that has the same format as the "Edmonton graph" file
void readGraph(const string& filename, WDigraph& g, unordered_map<int, Point>& points) {
  ifstream fin(filename);
  string line;

  while (getline(fin, line)) {
    // split the string around the commas, there will be 4 substrings either way
    string p[4];
    int at = 0;
    for (auto c : line) {
      if (c == ',') {
        // start new string
        ++at;
      }
      else {
        // append character to the string we are building
        p[at] += c;
      }
    }

    if (at != 3) {
      // empty line
      break;
    }

    if (p[0] == "V") {
      // new Point
      int id = stoi(p[1]);
      assert(id == stoll(p[1])); // sanity check: asserts if some id is not 32-bit
      points[id].lat = static_cast<long long>(stod(p[2])*100000);
      points[id].lon = static_cast<long long>(stod(p[3])*100000);
      g.addVertex(id);
    }
    else {
      // new directed edge
      int u = stoi(p[1]), v = stoi(p[2]);
      g.addEdge(u, v, manhattan(points[u], points[v]));
    }
  }
}

int create_and_open_fifo(const char * pname, int mode) {
  // creating a fifo special file in the current working directory
  // with read-write permissions for communication with the plotter
  // both proecsses must open the fifo before they can perform
  // read and write operations on it
  if (mkfifo(pname, 0666) == -1) {
    cout << "Unable to make a fifo. Ensure that this pipe does not exist already!" << endl;
    exit(-1);
  }

  // opening the fifo for read-only or write-only access
  // a file descriptor that refers to the open file description is
  // returned
  int fd = open(pname, mode);

  if (fd == -1) {
    cout << "Error: failed on opening named pipe." << endl;
    exit(-1);
  }

  return fd;
}

// keep in mind that in part 1, the program should only handle 1 request
// in part 2, you need to listen for a new request the moment you are done
// handling one request

int main() {
  // main function of this function, it will use the dijkstra to find a path between the start and the end points, 
  // it will uses fifo to read in the start and end points from the client and send the path to the client
  // Parameters: None
  // Returns: 0(which means the function runs successfully)

  WDigraph graph;
  unordered_map<int, Point> points;

  const char *inpipe = "inpipe";
  const char *outpipe = "outpipe";

  // Open the two pipes
  int in = create_and_open_fifo(inpipe, O_RDONLY);
  cout << "inpipe opened..." << endl;
  int out = create_and_open_fifo(outpipe, O_WRONLY);
  cout << "outpipe opened..." << endl;  

  // build the graph
  readGraph("server/edmonton-roads-2.0.1.txt", graph, points);

  // create the position of the start point and end point
  Point sPoint, ePoint;

  // a char array to store the start and end positions from the client
  char data[1024] = {0};

  while(true){
  // read the start and end positions from the client
    read(in,data,1024);
    
    // if the client sends Q, this means the program stops
    if(data[0] == 'Q'){
      break;
    }

    // create a string num to store the data in the char array
    string num;

    // count how many newline char we see
    int count = 0;

    // if we see 2 newline char in the data array, we have finished reading the 2 points
    // else, just  append the character to the end of the string
    for (uint i =0; i< 1024;i++){
      if (data[i] == '\n'){
        count ++;
        if (count == 2){
          break;
        }
      }
      // append the character in the char array to the end of string
      num = num + data[i];
    }

    // extract the start point lattitude
    sPoint.lat = static_cast<long long>(stod(num.substr(0, num.find(" ")))*100000);
    num.erase(0,num.find(" ")+1);

    // extract the start point longtitude
    sPoint.lon = static_cast<long long>(stod(num.substr(0, num.find(" ")))*100000);
    num.erase(0,num.find("\n")+1);

    // extract the end point lattitude
    ePoint.lat = static_cast<long long>(stod(num.substr(0, num.find(" ")))*100000);
    num.erase(0,num.find(" ")+1);

    // extract the end point longtitude
    ePoint.lon = static_cast<long long>(stod(num.substr(0, num.find(" ")))*100000);
    num.erase(0,num.find("\n")+1);

      // get the points closest to the two points we read
    int start = findClosest(sPoint, points), end = findClosest(ePoint, points);

    // run dijkstra's algorithm, this is the unoptimized version that
    // does not stop when the end is reached but it is still fast enough
    unordered_map<int, PIL> tree;
    dijkstra(graph, start, tree);

    // a list to store the vertex we go through
    list<int> path;

    // the char we send to client at the end of every request, which means no more vertex to be printed
    char ending[2] = {'E','\n'};

    // if there is no way between, just write ending
    if (tree.find(end) == tree.end()){
      write(out,ending, 2);
    }
    // if the start is the end, no point between, already at the destination, just write ending
    else if (start == end){
      write(out,ending, 2);
    }
    // there is a path between
    else{
      // go through the tree and get its path
      while(end!= start){
        path.push_front(end);
        end = tree[end].first;
      }
      path.push_front(start);

      // create a string to modify the data from long long to char array 
      string waypoint;

      // send every vertex in the path to the client
      for (int i:path){
        // a char array to store the actual characters we will write
        char writedata[1024] = {0};

        // get the lattitude of the vertex
        float lat = float(points[i].lat);
        //get lontitude of this vertex
        float lon = float(points[i].lon);
        
        // the lattitude and longtitude should be in its original format with decimals
        lat = lat/100000;
        lon = lon/100000;

        // make lat and lon in this format "lattitude longtidue\n"
        waypoint.append(to_string(lat)).pop_back();
        waypoint.append(" ");
        waypoint.append(to_string(lon)).pop_back();
        waypoint.append("\n");

        // copy the above string and save them to the writedata char array we created
        strcpy(writedata, waypoint.c_str());

        // send vertex info to the client
        write(out,writedata, strlen(writedata));
        
        // erase the string in case there is a new request from the client
        waypoint.erase();
      }

      // write the ending, this path has been fully sent
      write(out,ending, 2);
    }
  }

  // unlink and close the pipe
  unlink(inpipe);
  unlink(outpipe);
  close(in);
  close(out);
  
  

  return 0;
}
